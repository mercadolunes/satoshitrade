exports.allAccess = (req, res) => {
    res.status(200).send("Public Content.");
};

exports.index = (req, res) => {
    res.render('dashboard/boleto', { name: req.body.username })
  };







